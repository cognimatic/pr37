<?php

declare(strict_types = 1);

namespace Drupal\geocoder\Form;

/**
 * Provides a form to edit Geocoder provider entities.
 */
class GeocoderProviderEditForm extends GeocoderProviderFormBase {
}
