<?php

namespace Drupal\eca_user\Plugin\ECA\Condition;

use Drupal\eca\Plugin\ECA\Condition\ConditionBase;

/**
 * Base class for ECA condition plugins on current user.
 */
abstract class BaseUser extends ConditionBase {

}
