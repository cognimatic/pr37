<?php

namespace Drupal\eca_content\Plugin\Action;

/**
 * Interface for ECA actions that extend FieldUpdateActionBase.
 */
interface EcaFieldUpdateActionInterface {

}
