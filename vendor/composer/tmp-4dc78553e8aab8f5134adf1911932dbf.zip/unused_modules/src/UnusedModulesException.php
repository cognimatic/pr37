<?php

namespace Drupal\unused_modules;

/**
 * Exception thrown by UnusedModules.
 */
class UnusedModulesException extends \Exception {

}
